C = int(input("Enter the temperature in Celcius? "))
F = C * 1.8 + 32
print("{0} (C) = {1} (F)".format(C, F))
