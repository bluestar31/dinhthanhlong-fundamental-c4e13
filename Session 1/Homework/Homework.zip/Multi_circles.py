from turtle import *

shape("turtle")

speed(-1)

for i in range(50):
    circle(50)
    right(23)

mainloop()
