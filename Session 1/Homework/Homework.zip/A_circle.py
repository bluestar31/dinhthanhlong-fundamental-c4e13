from turtle import *

shape("turtle")

speed(1)

circle(50)

mainloop()
