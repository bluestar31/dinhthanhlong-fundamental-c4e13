r = float(input("Radius? "))
Area = 3.14 * r ** 2
print("Area = ", Area)
